self.addEventListener('install', event => {
  event.waitUntil(
    caches.open('water-puzzle-v1').then(cache => {
      return cache.addAll([
        '/',
        '/index.html',
        '/style.css',
        '/script.js',
        '/manifest.json',
        '/sw.js',
        '/icon-192.png',
        '/icon-512.png',
        '/pour.wav',
        '/win.wav'
      ]);
    })
  );
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request).then(response => response || fetch(event.request))
  );
});