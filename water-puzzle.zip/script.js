let containers = [];
let moveCount = 0;
let moveStack = [];
let volume = 1.0;
const sounds = {
  pour: new Audio('pour.wav'),
  win: new Audio('win.wav')
};

sounds.pour.volume = volume;
sounds.win.volume = volume;

const colors = ['red', 'green', 'orange'];

function createLevel(level) {
  containers = [];
  moveCount = 0;
  moveStack = [];
  document.getElementById('moves').innerText = 'Moves: 0';
  document.getElementById('game').innerHTML = '';
  document.getElementById('winMessage').classList.add('hidden');
  
  const numContainers = level + 2;
  for (let i = 0; i < numContainers; i++) {
    containers.push([]);
  }
  // Fill with random colors
  const allColors = colors.flatMap(c => [c, c, c]);
  while (allColors.length > 0) {
    const randIndex = Math.floor(Math.random() * allColors.length);
    for (let i = 0; i < containers.length; i++) {
      if (containers[i].length < 4) {
        containers[i].push(allColors.splice(randIndex, 1)[0]);
        break;
      }
    }
  }
  render();
}

function render() {
  const game = document.getElementById('game');
  game.innerHTML = '';
  containers.forEach((container, index) => {
    const div = document.createElement('div');
    div.className = 'container';
    div.dataset.index = index;
    container.forEach(color => {
      const c = document.createElement('div');
      c.className = 'color';
      c.style.backgroundColor = color;
      div.appendChild(c);
    });
    div.onclick = () => handleClick(index);
    game.appendChild(div);
  });
}

let selected = null;
function handleClick(index) {
  if (selected === null) {
    if (containers[index].length === 0) return;
    selected = index;
  } else {
    if (index !== selected && containers[index].length < 4) {
      const color = containers[selected].pop();
      containers[index].push(color);
      moveStack.push(JSON.parse(JSON.stringify(containers)));
      moveCount++;
      document.getElementById('moves').innerText = 'Moves: ' + moveCount;
      playSound('pour');
    }
    selected = null;
    render();
    checkWin();
  }
}

function undoMove() {
  if (moveStack.length > 0) {
    containers = moveStack.pop();
    moveCount--;
    document.getElementById('moves').innerText = 'Moves: ' + moveCount;
    render();
  }
}

function checkWin() {
  const win = containers.every(c => c.length === 0 || new Set(c).size === 1 && c.length === 4);
  if (win) {
    document.getElementById('winMessage').classList.remove('hidden');
    playSound('win');
  }
}

function playSound(name) {
  if (sounds[name]) {
    sounds[name].volume = volume;
    sounds[name].currentTime = 0;
    sounds[name].play();
  }
}

document.getElementById('volumeControl').addEventListener('input', function () {
  volume = parseFloat(this.value);
});

createLevel(3);